import en from './en.json';
import bn from './bn.json';

export { en, bn };
